package wtf.sheashaa.outis.controller;

public interface ClientStatus {
    void onDisconnected();
    void onConnected();
    void onConnecting();
}
