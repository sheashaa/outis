package wtf.sheashaa.outis.controller;

public interface GamepadListener {
    boolean onKey(int keyPress, boolean isPressed);
}
